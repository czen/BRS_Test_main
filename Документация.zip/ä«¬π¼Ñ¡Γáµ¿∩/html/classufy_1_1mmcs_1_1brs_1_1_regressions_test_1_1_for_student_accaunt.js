var classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_student_accaunt =
[
    [ "do_to_exam_journal", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_student_accaunt.html#a9837017a147b4fdf90588f4413a9590c", null ],
    [ "do_to_exam_marks", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_student_accaunt.html#a737752e75f31516cbfea6887187df6da", null ],
    [ "do_to_home", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_student_accaunt.html#a41461e313cc9f163eab0570558ebeafe", null ],
    [ "do_to_zach_jurnal", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_student_accaunt.html#a404f51a74cf23631e415fdb0b9b22cf6", null ],
    [ "do_to_zach_marks", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_student_accaunt.html#aeb40f2a3d049a67ab01f0aba8371149e", null ],
    [ "getDriver", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_student_accaunt.html#a0f4f803ef099e674149b7fc6628583e9", null ],
    [ "tearDown", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_student_accaunt.html#a6ff27540e3eade27eb60755736b301b5", null ],
    [ "url1", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_student_accaunt.html#a1b7aa5cdcc0febbad64ebb5a7d2d789b", null ],
    [ "url2", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_student_accaunt.html#ab5d88173c72dcfa19a54900ca3692b13", null ],
    [ "url3", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_student_accaunt.html#aafd5fc26a143608b38054b236a883f55", null ],
    [ "url4", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_student_accaunt.html#a3626b18c14bf61bec1c091c9c11e3237", null ],
    [ "url5", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_student_accaunt.html#a580ee1c817b98cdee4779200833adcd2", null ]
];