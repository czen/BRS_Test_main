var dir_462ff6ca53e683a76956fbb3d53e047b =
[
    [ "ForDekanatAccaunt.java", "_for_dekanat_accaunt_8java.html", [
      [ "ForDekanatAccaunt", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_dekanat_accaunt.html", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_dekanat_accaunt" ]
    ] ],
    [ "ForStudentAccaunt.java", "_for_student_accaunt_8java.html", [
      [ "ForStudentAccaunt", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_student_accaunt.html", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_student_accaunt" ]
    ] ],
    [ "ForTeacherAccaunt.java", "_for_teacher_accaunt_8java.html", [
      [ "ForTeacherAccaunt", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_teacher_accaunt.html", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_teacher_accaunt" ]
    ] ],
    [ "Helpers.java", "_helpers_8java.html", [
      [ "Helpers", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_helpers.html", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_helpers" ]
    ] ],
    [ "SimpleTests.java", "_simple_tests_8java.html", [
      [ "SimpleTests", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_simple_tests.html", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_simple_tests" ]
    ] ]
];