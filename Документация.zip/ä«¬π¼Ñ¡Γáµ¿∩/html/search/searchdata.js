var indexSectionsWithContent =
{
  0: "abcdefghijlmnprstuwzÐ",
  1: "aefhmpst",
  2: "u",
  3: "aefhmpst",
  4: "abcdefgijlmnprstuwz",
  5: "cdprstuw",
  6: "Ð"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "pages"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Пространства имен",
  3: "Файлы",
  4: "Функции",
  5: "Переменные",
  6: "Страницы"
};

