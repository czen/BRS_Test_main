var searchData=
[
  ['simpletests',['SimpleTests',['../classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_simple_tests.html',1,'ufy::mmcs::brs::RegressionsTest']]]
];
