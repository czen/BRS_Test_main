var searchData=
[
  ['marksforsemestrpagetest',['MarksForSemestrPageTest',['../classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_semestr_page_test.html',1,'ufy::mmcs::brs::TeacherTest']]],
  ['marksforsessiapagetest',['MarksForSessiaPageTest',['../classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_sessia_page_test.html',1,'ufy::mmcs::brs::TeacherTest']]],
  ['marksofzachetpagetest',['MarksOfZachetPageTest',['../classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_of_zachet_page_test.html',1,'ufy::mmcs::brs::TeacherTest']]]
];
