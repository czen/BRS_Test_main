var searchData=
[
  ['last_5fsemestr',['last_semestr',['../classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_helper.html#acb6e4915911678d47dc9d0a83df3c1b7',1,'ufy::mmcs::brs::TeacherTest::Helper']]]
];
