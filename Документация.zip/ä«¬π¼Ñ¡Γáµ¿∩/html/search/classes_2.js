var searchData=
[
  ['footerlinks',['FooterLinks',['../classufy_1_1mmcs_1_1brs_1_1_unauthorized_page_test_1_1_footer_links.html',1,'ufy::mmcs::brs::UnauthorizedPageTest']]],
  ['fordekanataccaunt',['ForDekanatAccaunt',['../classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_dekanat_accaunt.html',1,'ufy::mmcs::brs::RegressionsTest']]],
  ['forstudentaccaunt',['ForStudentAccaunt',['../classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_student_accaunt.html',1,'ufy::mmcs::brs::RegressionsTest']]],
  ['forteacheraccaunt',['ForTeacherAccaunt',['../classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_teacher_accaunt.html',1,'ufy::mmcs::brs::RegressionsTest']]]
];
