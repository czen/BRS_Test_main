var searchData=
[
  ['authorizationtest',['AuthorizationTest',['../namespaceufy_1_1mmcs_1_1brs_1_1_authorization_test.html',1,'ufy::mmcs::brs']]],
  ['brs',['brs',['../namespaceufy_1_1mmcs_1_1brs.html',1,'ufy::mmcs']]],
  ['mmcs',['mmcs',['../namespaceufy_1_1mmcs.html',1,'ufy']]],
  ['regressionstest',['RegressionsTest',['../namespaceufy_1_1mmcs_1_1brs_1_1_regressions_test.html',1,'ufy::mmcs::brs']]],
  ['studentpagetest',['StudentPageTest',['../namespaceufy_1_1mmcs_1_1brs_1_1_student_page_test.html',1,'ufy::mmcs::brs']]],
  ['teachertest',['TeacherTest',['../namespaceufy_1_1mmcs_1_1brs_1_1_teacher_test.html',1,'ufy::mmcs::brs']]],
  ['ufy',['ufy',['../namespaceufy.html',1,'']]],
  ['unauthorizedpagetest',['UnauthorizedPageTest',['../namespaceufy_1_1mmcs_1_1brs_1_1_unauthorized_page_test.html',1,'ufy::mmcs::brs']]]
];
