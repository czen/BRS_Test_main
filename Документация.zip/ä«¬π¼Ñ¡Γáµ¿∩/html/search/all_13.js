var searchData=
[
  ['zach_5fis_5fzach',['zach_is_zach',['../classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_teacher_test.html#a293c62dfd02f63995dbb611af6a57122',1,'ufy::mmcs::brs::TeacherTest::TeacherTest']]]
];
