var searchData=
[
  ['peresdacha1_5f22_5finput_5fperesdacha2',['peresdacha1_22_input_peresdacha2',['../classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_sessia_page_test.html#a62d31040df698add07e3f89dbad86597',1,'ufy::mmcs::brs::TeacherTest::MarksForSessiaPageTest']]],
  ['peresdacha1_5f22_5fset_5fneavka3',['peresdacha1_22_set_neavka3',['../classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_sessia_page_test.html#a20ca952af496ce79b62b23445f000347',1,'ufy::mmcs::brs::TeacherTest::MarksForSessiaPageTest']]],
  ['peresdacha2_5f10_5fset_5fneavka',['peresdacha2_10_set_neavka',['../classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_sessia_page_test.html#a41e5204444ba791a073b60235e21080b',1,'ufy::mmcs::brs::TeacherTest::MarksForSessiaPageTest']]],
  ['peresdacha2_5fdelete_5fdobor',['peresdacha2_delete_dobor',['../classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_sessia_page_test.html#a74b000e5f4be2d24fa447a90a878234d',1,'ufy::mmcs::brs::TeacherTest::MarksForSessiaPageTest']]],
  ['peresdacha2_5fdelete_5fneavka1',['peresdacha2_delete_neavka1',['../classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_sessia_page_test.html#aa16405d94c4604097f2404b44a089aab',1,'ufy::mmcs::brs::TeacherTest::MarksForSessiaPageTest']]],
  ['peresdacha2_5fdelete_5fneavka2',['peresdacha2_delete_neavka2',['../classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_sessia_page_test.html#a4bff67f2d37d716123123c262fb88315',1,'ufy::mmcs::brs::TeacherTest::MarksForSessiaPageTest']]]
];
