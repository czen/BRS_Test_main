var searchData=
[
  ['editdisciplinpagetest',['EditDisciplinPageTest',['../classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_edit_disciplin_page_test.html',1,'ufy::mmcs::brs::TeacherTest']]]
];
