var searchData=
[
  ['tabstest',['TabsTest',['../classufy_1_1mmcs_1_1brs_1_1_unauthorized_page_test_1_1_tabs_test.html',1,'ufy::mmcs::brs::UnauthorizedPageTest']]],
  ['teachertest',['TeacherTest',['../classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_teacher_test.html',1,'ufy::mmcs::brs::TeacherTest']]]
];
