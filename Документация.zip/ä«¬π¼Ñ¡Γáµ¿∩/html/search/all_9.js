var searchData=
[
  ['journal_5fpage_5ftabs',['journal_page_tabs',['../classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_after_click_btns_test.html#ac60fc17d703d9833dd554e5e6f170874',1,'ufy::mmcs::brs::TeacherTest::AfterClickBtnsTest']]]
];
