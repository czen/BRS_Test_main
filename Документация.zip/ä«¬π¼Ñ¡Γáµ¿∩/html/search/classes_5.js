var searchData=
[
  ['pageofdisciplin',['PageOfDisciplin',['../classufy_1_1mmcs_1_1brs_1_1_student_page_test_1_1_page_of_disciplin.html',1,'ufy::mmcs::brs::StudentPageTest']]],
  ['prosmotrdisciplinpagetest',['ProsmotrDisciplinPageTest',['../classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_prosmotr_disciplin_page_test.html',1,'ufy::mmcs::brs::TeacherTest']]]
];
