var namespaceufy_1_1mmcs_1_1brs_1_1_student_page_test =
[
    [ "Helper", "classufy_1_1mmcs_1_1brs_1_1_student_page_test_1_1_helper.html", "classufy_1_1mmcs_1_1brs_1_1_student_page_test_1_1_helper" ],
    [ "PageOfDisciplin", "classufy_1_1mmcs_1_1brs_1_1_student_page_test_1_1_page_of_disciplin.html", "classufy_1_1mmcs_1_1brs_1_1_student_page_test_1_1_page_of_disciplin" ]
];