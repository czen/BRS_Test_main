var classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_of_zachet_page_test =
[
    [ "add_delete_dobor_mark", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_of_zachet_page_test.html#aedf5d71afc4c05b4ec4bd842fd83248a", null ],
    [ "add_dobor2_mark_without_dobor1", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_of_zachet_page_test.html#a132100c437f77b1cdee05c11fbdbd076", null ],
    [ "add_dobor_mark_61_wrong", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_of_zachet_page_test.html#a7b7da6a793f0f8952bf737bd3e64eb71", null ],
    [ "add_dobor_mark_add_dobor2", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_of_zachet_page_test.html#afa873cf8efc99c5f7b1497cb43716a04", null ],
    [ "add_dobor_mark_add_dobor2_delete_dobor1", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_of_zachet_page_test.html#a421b7a8991a98a4d7173c8770e5df042", null ],
    [ "add_dobor_mark_add_dobor2_delete_dobor2", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_of_zachet_page_test.html#abd0b4ab32ce4678e3f780c378d01233d", null ],
    [ "add_dobor_mark_check_second_dobor_60", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_of_zachet_page_test.html#af503be8783fa2d8ad4252d8cdb7164dd", null ],
    [ "getDriver", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_of_zachet_page_test.html#afeec30367af535dfece7f13a13a9b0d1", null ],
    [ "set_avtomat_and_check_dobor", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_of_zachet_page_test.html#a487133546a9e874aad400aa507c054bd", null ],
    [ "tearDown", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_of_zachet_page_test.html#a9c8ffe5542ea13a9870ecb3056e87871", null ]
];