var namespaces_dup =
[
    [ "ufy", "namespaceufy.html", "namespaceufy" ]
];