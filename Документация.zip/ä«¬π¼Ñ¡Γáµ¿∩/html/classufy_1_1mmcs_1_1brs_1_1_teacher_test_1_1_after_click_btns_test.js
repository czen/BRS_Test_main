var classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_after_click_btns_test =
[
    [ "getDriver", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_after_click_btns_test.html#a2ffc9b60f6841679ef8143a041c418b7", null ],
    [ "journal_page_tabs", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_after_click_btns_test.html#ac60fc17d703d9833dd554e5e6f170874", null ],
    [ "semestr_page_tabs", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_after_click_btns_test.html#a94211194092e66f95ba26b682ed5fa79", null ],
    [ "semestr_page_tabs_click_history", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_after_click_btns_test.html#a00b62ef9208a03c327a7400978ad3453", null ],
    [ "semestr_page_tabs_click_sessia", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_after_click_btns_test.html#aadbafdaf1993cb7d2a6a5ee2154d5155", null ],
    [ "sessia_page_tabs", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_after_click_btns_test.html#a203b626c58ff48269380fcda7cd3604f", null ],
    [ "sessia_page_tabs_click_history", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_after_click_btns_test.html#aecddc51587bce2c8a4608e1ebe3aedc7", null ],
    [ "sessia_page_tabs_click_semestr", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_after_click_btns_test.html#a69af76b997386877c60e249503ade4ae", null ],
    [ "tearDown", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_after_click_btns_test.html#ac02ebd425ff2e5b8a7d2c2dda4204487", null ]
];