var classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_semestr_page_test =
[
    [ "add_mark_1", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_semestr_page_test.html#a5ad78d225c0205b2fadfb67f08a1e3c9", null ],
    [ "change_mark_1_for_2", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_semestr_page_test.html#af0906e97201bb373bcda9e805c125ccf", null ],
    [ "check_empty_string", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_semestr_page_test.html#a81536467719a90454190148d045c7caa", null ],
    [ "check_mark_1_with_minus", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_semestr_page_test.html#a15964fb34032ad654ea58c2e27a914ba", null ],
    [ "check_mark_over_max", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_semestr_page_test.html#a5c3758d33cd83cb8f98d4794a650e6d6", null ],
    [ "check_mark_to_bonus", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_semestr_page_test.html#a6d52d4a2c0537c29248addc9f0ad8603", null ],
    [ "check_summ_mark_in_string", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_semestr_page_test.html#a7d8c2c4e50b48b762e93c404971250d5", null ],
    [ "delete_mark_1", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_semestr_page_test.html#aceb2d02c194b696a2d7e8a4b9160e98c", null ],
    [ "getDriver", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_semestr_page_test.html#a4f8caac1199e778fef62b546b53c08da", null ],
    [ "input_wrong_mark_0", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_semestr_page_test.html#ad6adba56dc38da73ebfe18fb2643687f", null ],
    [ "input_wrong_mark_101", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_semestr_page_test.html#a440bd7c652d7cfb91159cfef66e11527", null ],
    [ "summ_mark_1_and_2", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_semestr_page_test.html#a6191c1cabf51cce353a569902f75fcc1", null ],
    [ "tearDown", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_semestr_page_test.html#a727209cc26e1b35d3d24376b0abb3cda", null ]
];