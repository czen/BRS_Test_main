var namespaceufy_1_1mmcs_1_1brs_1_1_teacher_test =
[
    [ "AfterClickBtnsTest", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_after_click_btns_test.html", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_after_click_btns_test" ],
    [ "EditDisciplinPageTest", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_edit_disciplin_page_test.html", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_edit_disciplin_page_test" ],
    [ "Helper", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_helper.html", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_helper" ],
    [ "MarksForSemestrPageTest", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_semestr_page_test.html", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_semestr_page_test" ],
    [ "MarksForSessiaPageTest", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_sessia_page_test.html", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_sessia_page_test" ],
    [ "MarksOfZachetPageTest", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_of_zachet_page_test.html", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_of_zachet_page_test" ],
    [ "ProsmotrDisciplinPageTest", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_prosmotr_disciplin_page_test.html", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_prosmotr_disciplin_page_test" ],
    [ "TeacherTest", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_teacher_test.html", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_teacher_test" ]
];