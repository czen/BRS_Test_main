var dir_5c1a9ec63c36ba33c494d78b4037d10c =
[
    [ "AfterClickBtnsTest.java", "_after_click_btns_test_8java.html", [
      [ "AfterClickBtnsTest", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_after_click_btns_test.html", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_after_click_btns_test" ]
    ] ],
    [ "EditDisciplinPageTest.java", "_edit_disciplin_page_test_8java.html", [
      [ "EditDisciplinPageTest", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_edit_disciplin_page_test.html", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_edit_disciplin_page_test" ]
    ] ],
    [ "Helper.java", "_teacher_test_2_helper_8java.html", [
      [ "Helper", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_helper.html", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_helper" ]
    ] ],
    [ "MarksForSemestrPageTest.java", "_marks_for_semestr_page_test_8java.html", [
      [ "MarksForSemestrPageTest", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_semestr_page_test.html", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_semestr_page_test" ]
    ] ],
    [ "MarksForSessiaPageTest.java", "_marks_for_sessia_page_test_8java.html", [
      [ "MarksForSessiaPageTest", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_sessia_page_test.html", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_sessia_page_test" ]
    ] ],
    [ "MarksOfZachetPageTest.java", "_marks_of_zachet_page_test_8java.html", [
      [ "MarksOfZachetPageTest", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_of_zachet_page_test.html", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_of_zachet_page_test" ]
    ] ],
    [ "ProsmotrDisciplinPageTest.java", "_prosmotr_disciplin_page_test_8java.html", [
      [ "ProsmotrDisciplinPageTest", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_prosmotr_disciplin_page_test.html", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_prosmotr_disciplin_page_test" ]
    ] ],
    [ "TeacherTest.java", "_teacher_test_8java.html", [
      [ "TeacherTest", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_teacher_test.html", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_teacher_test" ]
    ] ]
];