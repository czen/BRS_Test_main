var namespaceufy_1_1mmcs_1_1brs_1_1_authorization_test =
[
    [ "AuthorizationFormTest", "classufy_1_1mmcs_1_1brs_1_1_authorization_test_1_1_authorization_form_test.html", "classufy_1_1mmcs_1_1brs_1_1_authorization_test_1_1_authorization_form_test" ],
    [ "AuthorizationTest", "classufy_1_1mmcs_1_1brs_1_1_authorization_test_1_1_authorization_test.html", "classufy_1_1mmcs_1_1brs_1_1_authorization_test_1_1_authorization_test" ],
    [ "Helper", "classufy_1_1mmcs_1_1brs_1_1_authorization_test_1_1_helper.html", "classufy_1_1mmcs_1_1brs_1_1_authorization_test_1_1_helper" ]
];