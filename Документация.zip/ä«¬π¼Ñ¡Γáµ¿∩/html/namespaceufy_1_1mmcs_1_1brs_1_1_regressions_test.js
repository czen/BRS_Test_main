var namespaceufy_1_1mmcs_1_1brs_1_1_regressions_test =
[
    [ "ForDekanatAccaunt", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_dekanat_accaunt.html", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_dekanat_accaunt" ],
    [ "ForStudentAccaunt", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_student_accaunt.html", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_student_accaunt" ],
    [ "ForTeacherAccaunt", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_teacher_accaunt.html", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_teacher_accaunt" ],
    [ "Helpers", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_helpers.html", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_helpers" ],
    [ "SimpleTests", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_simple_tests.html", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_simple_tests" ]
];