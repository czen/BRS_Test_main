var dir_5b19e859ac4a806a22bdc95e2a4a3ea9 =
[
    [ "Helper.java", "_student_page_test_2_helper_8java.html", [
      [ "Helper", "classufy_1_1mmcs_1_1brs_1_1_student_page_test_1_1_helper.html", "classufy_1_1mmcs_1_1brs_1_1_student_page_test_1_1_helper" ]
    ] ],
    [ "PageOfDisciplin.java", "_page_of_disciplin_8java.html", [
      [ "PageOfDisciplin", "classufy_1_1mmcs_1_1brs_1_1_student_page_test_1_1_page_of_disciplin.html", "classufy_1_1mmcs_1_1brs_1_1_student_page_test_1_1_page_of_disciplin" ]
    ] ]
];