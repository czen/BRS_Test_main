var dir_449790260d4b5cdb2825a595a44fa521 =
[
    [ "AuthorizationFormTest.java", "_authorization_form_test_8java.html", [
      [ "AuthorizationFormTest", "classufy_1_1mmcs_1_1brs_1_1_authorization_test_1_1_authorization_form_test.html", "classufy_1_1mmcs_1_1brs_1_1_authorization_test_1_1_authorization_form_test" ]
    ] ],
    [ "AuthorizationTest.java", "_authorization_test_8java.html", [
      [ "AuthorizationTest", "classufy_1_1mmcs_1_1brs_1_1_authorization_test_1_1_authorization_test.html", "classufy_1_1mmcs_1_1brs_1_1_authorization_test_1_1_authorization_test" ]
    ] ],
    [ "Helper.java", "_authorization_test_2_helper_8java.html", [
      [ "Helper", "classufy_1_1mmcs_1_1brs_1_1_authorization_test_1_1_helper.html", "classufy_1_1mmcs_1_1brs_1_1_authorization_test_1_1_helper" ]
    ] ]
];