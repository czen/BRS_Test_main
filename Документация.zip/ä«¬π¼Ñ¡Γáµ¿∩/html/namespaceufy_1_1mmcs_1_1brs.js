var namespaceufy_1_1mmcs_1_1brs =
[
    [ "AuthorizationTest", "namespaceufy_1_1mmcs_1_1brs_1_1_authorization_test.html", "namespaceufy_1_1mmcs_1_1brs_1_1_authorization_test" ],
    [ "RegressionsTest", "namespaceufy_1_1mmcs_1_1brs_1_1_regressions_test.html", "namespaceufy_1_1mmcs_1_1brs_1_1_regressions_test" ],
    [ "StudentPageTest", "namespaceufy_1_1mmcs_1_1brs_1_1_student_page_test.html", "namespaceufy_1_1mmcs_1_1brs_1_1_student_page_test" ],
    [ "TeacherTest", "namespaceufy_1_1mmcs_1_1brs_1_1_teacher_test.html", "namespaceufy_1_1mmcs_1_1brs_1_1_teacher_test" ],
    [ "UnauthorizedPageTest", "namespaceufy_1_1mmcs_1_1brs_1_1_unauthorized_page_test.html", "namespaceufy_1_1mmcs_1_1brs_1_1_unauthorized_page_test" ],
    [ "App", "classufy_1_1mmcs_1_1brs_1_1_app.html", "classufy_1_1mmcs_1_1brs_1_1_app" ]
];