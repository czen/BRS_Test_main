var annotated_dup =
[
    [ "ufy", "namespaceufy.html", "namespaceufy" ]
];