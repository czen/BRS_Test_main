var classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_simple_tests =
[
    [ "getDriver", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_simple_tests.html#a503e0a3a47eebc99d1c23a31dcbecf37", null ],
    [ "go_to_home", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_simple_tests.html#a381c250aacab2ecd615f8273a4268b5a", null ],
    [ "go_to_remind", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_simple_tests.html#a013c21eb250bb929aaf3a9562877d939", null ],
    [ "go_to_sign_in", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_simple_tests.html#af591ea413f26be84307949c5b7bbf164", null ],
    [ "go_to_sign_up", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_simple_tests.html#a0b3bd4521717ea11d74bab192f102490", null ],
    [ "tearDown", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_simple_tests.html#ab2511d17e7b6e10d8d38e7b9175c538c", null ],
    [ "url1", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_simple_tests.html#afc2b9c861d8d30381cbbdf87222aa92e", null ],
    [ "url2", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_simple_tests.html#a9cc8bae7fd340001255ca0bd4dddb65a", null ],
    [ "url3", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_simple_tests.html#ab12e9391d815514496d620e6da2c5e07", null ],
    [ "url4", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_simple_tests.html#a6a6fb96f54de89f2834fc2ba52f7b615", null ]
];