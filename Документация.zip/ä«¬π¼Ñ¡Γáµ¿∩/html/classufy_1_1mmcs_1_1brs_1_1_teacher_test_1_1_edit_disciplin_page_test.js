var classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_edit_disciplin_page_test =
[
    [ "add_and_delete_modules", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_edit_disciplin_page_test.html#abb39aa1f72976655659c350b5f11a3f4", null ],
    [ "add_and_delete_submodule", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_edit_disciplin_page_test.html#aae840845ce8e73c7843df4c7ba1060f9", null ],
    [ "click_down_from_lower_moduls", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_edit_disciplin_page_test.html#ab7ed1b772ed0b245487186145183352b", null ],
    [ "click_down_from_up_modul", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_edit_disciplin_page_test.html#ae5c2428b5c171fab8ca6c59550900a35", null ],
    [ "click_submodule_to_down_from_lower", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_edit_disciplin_page_test.html#afe0406bd9ff4c5de3cc055b398d7c9df", null ],
    [ "click_submodule_to_up_from_higher", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_edit_disciplin_page_test.html#a9b9ce39da96708b1d0749143ef0b0c8c", null ],
    [ "delete_module", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_edit_disciplin_page_test.html#a5f83fb0698852502c2914d3c1d0c8d73", null ],
    [ "getDriver", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_edit_disciplin_page_test.html#ae7d6754a68a66cb4ff318570053747a0", null ],
    [ "sort_submodules_to_down", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_edit_disciplin_page_test.html#addb73f8327ab6340d7484d1f1e69b824", null ],
    [ "sort_submodules_to_up", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_edit_disciplin_page_test.html#afb1514ee6d3c50c1d2bde7352c3f5946", null ],
    [ "sort_to_down_moduls", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_edit_disciplin_page_test.html#a9aafb2a273e0c051e778e95983d4ede8", null ],
    [ "sort_to_up_moduls", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_edit_disciplin_page_test.html#a19a3ba2cc47a36aeaa37454e915d1578", null ],
    [ "tearDown", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_edit_disciplin_page_test.html#a5587de53176b0ff6fef2b8b06518c339", null ],
    [ "the_page_of_redact_is_exist", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_edit_disciplin_page_test.html#a09c82bc71b1925cb3438078c780ea21f", null ],
    [ "url", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_edit_disciplin_page_test.html#a89482dbaef26b9f046448913fc0f78e3", null ]
];