var classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_prosmotr_disciplin_page_test =
[
    [ "add_and_delete_teacher", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_prosmotr_disciplin_page_test.html#a50ee4219a7ba1d24b1bebabad3490ce6", null ],
    [ "check_prosmotr", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_prosmotr_disciplin_page_test.html#a305730083d1a36c270280b5d2c832c56", null ],
    [ "click_to_teachers", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_prosmotr_disciplin_page_test.html#acaae6c58b8ac987e77ba6e9a75dceaf6", null ],
    [ "getDriver", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_prosmotr_disciplin_page_test.html#a31dc31acf6568fdfd35d2febc44dfb64", null ],
    [ "give_leads_to_another_teacher", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_prosmotr_disciplin_page_test.html#a84843e6c92e08d263ba2ee499b59df4b", null ],
    [ "search_teacher_yet_in_aded", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_prosmotr_disciplin_page_test.html#ad66d457fe8392004e3804940b9f133f9", null ],
    [ "tearDown", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_prosmotr_disciplin_page_test.html#a25399db296128c9243681a0261def212", null ]
];