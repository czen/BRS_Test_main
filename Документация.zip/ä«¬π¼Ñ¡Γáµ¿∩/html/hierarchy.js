var hierarchy =
[
    [ "ufy.mmcs.brs.App", "classufy_1_1mmcs_1_1brs_1_1_app.html", null ],
    [ "ufy.mmcs.brs.AuthorizationTest.Helper", "classufy_1_1mmcs_1_1brs_1_1_authorization_test_1_1_helper.html", [
      [ "ufy.mmcs.brs.AuthorizationTest.AuthorizationFormTest", "classufy_1_1mmcs_1_1brs_1_1_authorization_test_1_1_authorization_form_test.html", null ],
      [ "ufy.mmcs.brs.AuthorizationTest.AuthorizationTest", "classufy_1_1mmcs_1_1brs_1_1_authorization_test_1_1_authorization_test.html", null ]
    ] ],
    [ "ufy.mmcs.brs.UnauthorizedPageTest.Helper", "classufy_1_1mmcs_1_1brs_1_1_unauthorized_page_test_1_1_helper.html", [
      [ "ufy.mmcs.brs.UnauthorizedPageTest.FooterLinks", "classufy_1_1mmcs_1_1brs_1_1_unauthorized_page_test_1_1_footer_links.html", null ],
      [ "ufy.mmcs.brs.UnauthorizedPageTest.TabsTest", "classufy_1_1mmcs_1_1brs_1_1_unauthorized_page_test_1_1_tabs_test.html", null ]
    ] ],
    [ "ufy.mmcs.brs.StudentPageTest.Helper", "classufy_1_1mmcs_1_1brs_1_1_student_page_test_1_1_helper.html", [
      [ "ufy.mmcs.brs.StudentPageTest.PageOfDisciplin", "classufy_1_1mmcs_1_1brs_1_1_student_page_test_1_1_page_of_disciplin.html", null ]
    ] ],
    [ "ufy.mmcs.brs.TeacherTest.Helper", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_helper.html", [
      [ "ufy.mmcs.brs.TeacherTest.AfterClickBtnsTest", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_after_click_btns_test.html", null ],
      [ "ufy.mmcs.brs.TeacherTest.EditDisciplinPageTest", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_edit_disciplin_page_test.html", null ],
      [ "ufy.mmcs.brs.TeacherTest.MarksForSemestrPageTest", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_semestr_page_test.html", null ],
      [ "ufy.mmcs.brs.TeacherTest.MarksForSessiaPageTest", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_for_sessia_page_test.html", null ],
      [ "ufy.mmcs.brs.TeacherTest.MarksOfZachetPageTest", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_marks_of_zachet_page_test.html", null ],
      [ "ufy.mmcs.brs.TeacherTest.ProsmotrDisciplinPageTest", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_prosmotr_disciplin_page_test.html", null ],
      [ "ufy.mmcs.brs.TeacherTest.TeacherTest", "classufy_1_1mmcs_1_1brs_1_1_teacher_test_1_1_teacher_test.html", null ]
    ] ],
    [ "ufy.mmcs.brs.RegressionsTest.Helpers", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_helpers.html", [
      [ "ufy.mmcs.brs.RegressionsTest.ForDekanatAccaunt", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_dekanat_accaunt.html", null ],
      [ "ufy.mmcs.brs.RegressionsTest.ForStudentAccaunt", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_student_accaunt.html", null ],
      [ "ufy.mmcs.brs.RegressionsTest.ForTeacherAccaunt", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_for_teacher_accaunt.html", null ],
      [ "ufy.mmcs.brs.RegressionsTest.SimpleTests", "classufy_1_1mmcs_1_1brs_1_1_regressions_test_1_1_simple_tests.html", null ]
    ] ]
];