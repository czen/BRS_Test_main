var dir_95b9ea3fa0f9f6bfae6a9b4cca54c7af =
[
    [ "AuthorizationTest", "dir_ec290d967e74ae48b7a74501e7e24e67.html", "dir_ec290d967e74ae48b7a74501e7e24e67" ],
    [ "RegressionsTest", "dir_235ca710f56af6003cd03de94157ead8.html", "dir_235ca710f56af6003cd03de94157ead8" ],
    [ "StudentPageTest", "dir_a2ada979a34dda9740cd42815f6e1b53.html", "dir_a2ada979a34dda9740cd42815f6e1b53" ],
    [ "TeacherTest", "dir_12b339df518005d24d93c4b7c764e134.html", "dir_12b339df518005d24d93c4b7c764e134" ],
    [ "UnauthorizedPageTest", "dir_d84ca9949633542472d3f6f4e8fc5d74.html", "dir_d84ca9949633542472d3f6f4e8fc5d74" ]
];