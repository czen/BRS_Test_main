var classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_marks_of_zachet_page_test =
[
    [ "add_delete_dobor_mark", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_marks_of_zachet_page_test.html#a2898acc15285bc689177f5276fdd879b", null ],
    [ "add_dobor2_mark_without_dobor1", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_marks_of_zachet_page_test.html#a14a5e048da6d67afe4b419326d53a04a", null ],
    [ "add_dobor_mark_61_wrong", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_marks_of_zachet_page_test.html#a79966749b1b7267b22de05f145331862", null ],
    [ "add_dobor_mark_add_dobor2", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_marks_of_zachet_page_test.html#afee159825bb228995f0ca04cc63cbedf", null ],
    [ "add_dobor_mark_add_dobor2_delete_dobor1", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_marks_of_zachet_page_test.html#aa34cc8dd24bca658ab47e9839baf6e33", null ],
    [ "add_dobor_mark_add_dobor2_delete_dobor2", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_marks_of_zachet_page_test.html#ace045cf22cbd9fd416db4bc90234f580", null ],
    [ "add_dobor_mark_check_second_dobor_60", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_marks_of_zachet_page_test.html#a092fa0a0ae99936446e7c41c80db9fe8", null ],
    [ "getDriver", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_marks_of_zachet_page_test.html#a2b8abd92a4a07529ca68b935509d7685", null ],
    [ "set_avtomat_and_check_dobor", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_marks_of_zachet_page_test.html#acb157aee45596c6669eb9d62a1f1d65c", null ],
    [ "tearDown", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_marks_of_zachet_page_test.html#aff4141927837d9af899b2e5a986f177b", null ]
];