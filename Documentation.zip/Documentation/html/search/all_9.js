var searchData=
[
  ['journal_5fpage_5ftabs',['journal_page_tabs',['../classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_after_click_btns_test.html#a9e85258fac8c17923f3bba98b33d68a5',1,'ru::sfedu::grade::TeacherTest::AfterClickBtnsTest']]]
];
