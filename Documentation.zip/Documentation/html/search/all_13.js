var searchData=
[
  ['zach_5fis_5fzach',['zach_is_zach',['../classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_teacher_test.html#a050124ae029271269ab2a13b75b1e3d9',1,'ru::sfedu::grade::TeacherTest::TeacherTest']]]
];
