var searchData=
[
  ['simpletests',['SimpleTests',['../classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_simple_tests.html',1,'ru::sfedu::grade::RegressionsTest']]]
];
