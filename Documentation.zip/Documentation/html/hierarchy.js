var hierarchy =
[
    [ "ru.sfedu.grade.StudentPageTest.Helper", "classru_1_1sfedu_1_1grade_1_1_student_page_test_1_1_helper.html", [
      [ "ru.sfedu.grade.StudentPageTest.PageOfDisciplin", "classru_1_1sfedu_1_1grade_1_1_student_page_test_1_1_page_of_disciplin.html", null ]
    ] ],
    [ "ru.sfedu.grade.UnauthorizedPageTest.Helper", "classru_1_1sfedu_1_1grade_1_1_unauthorized_page_test_1_1_helper.html", [
      [ "ru.sfedu.grade.UnauthorizedPageTest.FooterLinks", "classru_1_1sfedu_1_1grade_1_1_unauthorized_page_test_1_1_footer_links.html", null ],
      [ "ru.sfedu.grade.UnauthorizedPageTest.TabsTest", "classru_1_1sfedu_1_1grade_1_1_unauthorized_page_test_1_1_tabs_test.html", null ]
    ] ],
    [ "ru.sfedu.grade.AuthorizationTest.Helper", "classru_1_1sfedu_1_1grade_1_1_authorization_test_1_1_helper.html", [
      [ "ru.sfedu.grade.AuthorizationTest.AuthorizationFormTest", "classru_1_1sfedu_1_1grade_1_1_authorization_test_1_1_authorization_form_test.html", null ],
      [ "ru.sfedu.grade.AuthorizationTest.AuthorizationTest", "classru_1_1sfedu_1_1grade_1_1_authorization_test_1_1_authorization_test.html", null ]
    ] ],
    [ "ru.sfedu.grade.TeacherTest.Helper", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_helper.html", [
      [ "ru.sfedu.grade.TeacherTest.AfterClickBtnsTest", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_after_click_btns_test.html", null ],
      [ "ru.sfedu.grade.TeacherTest.EditDisciplinPageTest", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_edit_disciplin_page_test.html", null ],
      [ "ru.sfedu.grade.TeacherTest.MarksForSemestrPageTest", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_marks_for_semestr_page_test.html", null ],
      [ "ru.sfedu.grade.TeacherTest.MarksForSessiaPageTest", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_marks_for_sessia_page_test.html", null ],
      [ "ru.sfedu.grade.TeacherTest.MarksOfZachetPageTest", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_marks_of_zachet_page_test.html", null ],
      [ "ru.sfedu.grade.TeacherTest.ProsmotrDisciplinPageTest", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_prosmotr_disciplin_page_test.html", null ],
      [ "ru.sfedu.grade.TeacherTest.TeacherTest", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_teacher_test.html", null ]
    ] ],
    [ "ru.sfedu.grade.RegressionsTest.Helpers", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_helpers.html", [
      [ "ru.sfedu.grade.RegressionsTest.ForDekanatAccaunt", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_dekanat_accaunt.html", null ],
      [ "ru.sfedu.grade.RegressionsTest.ForStudentAccaunt", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_student_accaunt.html", null ],
      [ "ru.sfedu.grade.RegressionsTest.ForTeacherAccaunt", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_teacher_accaunt.html", null ],
      [ "ru.sfedu.grade.RegressionsTest.SimpleTests", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_simple_tests.html", null ]
    ] ]
];