var annotated_dup =
[
    [ "ru", "namespaceru.html", "namespaceru" ]
];