var classru_1_1sfedu_1_1grade_1_1_unauthorized_page_test_1_1_tabs_test =
[
    [ "getDriver", "classru_1_1sfedu_1_1grade_1_1_unauthorized_page_test_1_1_tabs_test.html#a5a8ee1e4af2e166a99403fecbb937079", null ],
    [ "news_is_not_select_syncs", "classru_1_1sfedu_1_1grade_1_1_unauthorized_page_test_1_1_tabs_test.html#a432854927050945891eb5876177e7725", null ],
    [ "news_is_not_select_upd", "classru_1_1sfedu_1_1grade_1_1_unauthorized_page_test_1_1_tabs_test.html#a370657a57c9364869d955530c3b2a9b4", null ],
    [ "news_is_select_home", "classru_1_1sfedu_1_1grade_1_1_unauthorized_page_test_1_1_tabs_test.html#a3cc7a73fe87311fdafb63ef9242c6bef", null ],
    [ "news_is_select_yet", "classru_1_1sfedu_1_1grade_1_1_unauthorized_page_test_1_1_tabs_test.html#acc502fb3b3fcab2b909b6c482b09ff70", null ],
    [ "syncs_click", "classru_1_1sfedu_1_1grade_1_1_unauthorized_page_test_1_1_tabs_test.html#a530f956506efced570a61d2c6e76812a", null ],
    [ "syncs_expand_click", "classru_1_1sfedu_1_1grade_1_1_unauthorized_page_test_1_1_tabs_test.html#ada48890719c55f23c77aeaa17435e5a0", null ],
    [ "syncs_expand_click_click", "classru_1_1sfedu_1_1grade_1_1_unauthorized_page_test_1_1_tabs_test.html#ab51b8f8e2af92791c50a236f0e25fd41", null ],
    [ "syncs_is_not_select_home", "classru_1_1sfedu_1_1grade_1_1_unauthorized_page_test_1_1_tabs_test.html#a007310443f3639e19225c55b62c455c0", null ],
    [ "syncs_is_not_select_upd", "classru_1_1sfedu_1_1grade_1_1_unauthorized_page_test_1_1_tabs_test.html#a12912cbc650c3a5d875c7e2d7335b6bc", null ],
    [ "tabs_names", "classru_1_1sfedu_1_1grade_1_1_unauthorized_page_test_1_1_tabs_test.html#a6adbcb910ac4b2f45fe355ed411376c7", null ],
    [ "tearDown", "classru_1_1sfedu_1_1grade_1_1_unauthorized_page_test_1_1_tabs_test.html#a67c6b8a9694b8cf22ba14acbb960e9ca", null ],
    [ "upd_expand_click", "classru_1_1sfedu_1_1grade_1_1_unauthorized_page_test_1_1_tabs_test.html#afd5b05439e9595a7d61744388c44560b", null ],
    [ "upd_expand_click_click", "classru_1_1sfedu_1_1grade_1_1_unauthorized_page_test_1_1_tabs_test.html#abfb3bd17afc51cdf2ce7e163795e25a8", null ],
    [ "upd_is_not_select_syncs", "classru_1_1sfedu_1_1grade_1_1_unauthorized_page_test_1_1_tabs_test.html#acd3d6321559e6965ed8b28a4a4d7fc83", null ],
    [ "update_click", "classru_1_1sfedu_1_1grade_1_1_unauthorized_page_test_1_1_tabs_test.html#a134a7c9f6bfda608da4614f8c4791c45", null ],
    [ "updates_is_not_select_home", "classru_1_1sfedu_1_1grade_1_1_unauthorized_page_test_1_1_tabs_test.html#a49bfd2f9555119bc5f4f65d0c62c08f7", null ]
];