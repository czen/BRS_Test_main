var classru_1_1sfedu_1_1grade_1_1_student_page_test_1_1_page_of_disciplin =
[
    [ "getDriver", "classru_1_1sfedu_1_1grade_1_1_student_page_test_1_1_page_of_disciplin.html#a03fe10ffa3e77e8bb3701ce26b5c8349", null ],
    [ "go_to_baals_after_journal", "classru_1_1sfedu_1_1grade_1_1_student_page_test_1_1_page_of_disciplin.html#a67cd89ccd0cecad6cdd4e11b05906a1f", null ],
    [ "go_to_balls", "classru_1_1sfedu_1_1grade_1_1_student_page_test_1_1_page_of_disciplin.html#ab02a7460d122f7067010acc7320ca1ab", null ],
    [ "go_to_journal", "classru_1_1sfedu_1_1grade_1_1_student_page_test_1_1_page_of_disciplin.html#a57f04402c62fd0f6d16a90caa3d11b6d", null ],
    [ "tearDown", "classru_1_1sfedu_1_1grade_1_1_student_page_test_1_1_page_of_disciplin.html#a6760aaeb14c81209bc82cddc9713ae8e", null ]
];