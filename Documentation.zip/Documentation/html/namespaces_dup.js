var namespaces_dup =
[
    [ "ru", "namespaceru.html", "namespaceru" ]
];