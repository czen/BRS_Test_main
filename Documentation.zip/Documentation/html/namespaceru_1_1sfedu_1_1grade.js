var namespaceru_1_1sfedu_1_1grade =
[
    [ "AuthorizationTest", "namespaceru_1_1sfedu_1_1grade_1_1_authorization_test.html", "namespaceru_1_1sfedu_1_1grade_1_1_authorization_test" ],
    [ "RegressionsTest", "namespaceru_1_1sfedu_1_1grade_1_1_regressions_test.html", "namespaceru_1_1sfedu_1_1grade_1_1_regressions_test" ],
    [ "StudentPageTest", "namespaceru_1_1sfedu_1_1grade_1_1_student_page_test.html", "namespaceru_1_1sfedu_1_1grade_1_1_student_page_test" ],
    [ "TeacherTest", "namespaceru_1_1sfedu_1_1grade_1_1_teacher_test.html", "namespaceru_1_1sfedu_1_1grade_1_1_teacher_test" ],
    [ "UnauthorizedPageTest", "namespaceru_1_1sfedu_1_1grade_1_1_unauthorized_page_test.html", "namespaceru_1_1sfedu_1_1grade_1_1_unauthorized_page_test" ]
];