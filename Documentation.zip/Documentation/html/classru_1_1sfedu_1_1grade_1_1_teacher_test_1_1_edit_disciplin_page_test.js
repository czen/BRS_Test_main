var classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_edit_disciplin_page_test =
[
    [ "add_and_delete_modules", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_edit_disciplin_page_test.html#aad5e29ed09f67464b99cb4136bf97cfb", null ],
    [ "add_and_delete_submodule", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_edit_disciplin_page_test.html#aa34d10de09c51eb801d2e1496e852226", null ],
    [ "click_down_from_lower_moduls", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_edit_disciplin_page_test.html#a6b7fbc9e4572005377ce3221a6f8d7d8", null ],
    [ "click_down_from_up_modul", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_edit_disciplin_page_test.html#a17659e918b92e909e3397e02d1a0b975", null ],
    [ "click_submodule_to_down_from_lower", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_edit_disciplin_page_test.html#a26404f7f1e07c602af062fb362bb37e1", null ],
    [ "click_submodule_to_up_from_higher", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_edit_disciplin_page_test.html#a1695aaeb15731d6a6d0e1a06176a4741", null ],
    [ "delete_module", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_edit_disciplin_page_test.html#a4c9c3e4c66d0c6a3026c1ae23040e61c", null ],
    [ "getDriver", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_edit_disciplin_page_test.html#afbb1f06dea7322711fad54383d60477b", null ],
    [ "sort_submodules_to_down", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_edit_disciplin_page_test.html#a72c4e016a471f4bd5624491f00cd19c9", null ],
    [ "sort_submodules_to_up", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_edit_disciplin_page_test.html#a832bfe232ca84c44faf774602ad80e2d", null ],
    [ "sort_to_down_moduls", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_edit_disciplin_page_test.html#a4122f3ef12a6de61a27de96f62a281bf", null ],
    [ "sort_to_up_moduls", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_edit_disciplin_page_test.html#a1ca8a3453dfb076f6a2cec86f44d04c8", null ],
    [ "tearDown", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_edit_disciplin_page_test.html#a148406af8235f00082874fd22ca10ef4", null ],
    [ "the_page_of_redact_is_exist", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_edit_disciplin_page_test.html#a8fd05fac06617ca817fb87a4474462f6", null ],
    [ "url", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_edit_disciplin_page_test.html#ae12baaa54be1ef0a516435c7146cf5bb", null ]
];