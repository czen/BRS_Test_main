var classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_after_click_btns_test =
[
    [ "getDriver", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_after_click_btns_test.html#a579a6cca1350d59d8d2fc39aee0c487f", null ],
    [ "journal_page_tabs", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_after_click_btns_test.html#a9e85258fac8c17923f3bba98b33d68a5", null ],
    [ "semestr_page_tabs", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_after_click_btns_test.html#add41772be850a1358211790b573f9ffc", null ],
    [ "semestr_page_tabs_click_history", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_after_click_btns_test.html#a7c2fafbe61ebef1bb5e98d9984d34a22", null ],
    [ "semestr_page_tabs_click_sessia", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_after_click_btns_test.html#a2e834b59cd3c5da225ab425c2c93bc15", null ],
    [ "sessia_page_tabs", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_after_click_btns_test.html#af6d090f3d638e04cb8033382629db8a5", null ],
    [ "sessia_page_tabs_click_history", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_after_click_btns_test.html#a2390cbd9bf4a376c6cbb70fe94f12b0a", null ],
    [ "sessia_page_tabs_click_semestr", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_after_click_btns_test.html#a7af524191f80c59f80560b35dd851fb1", null ],
    [ "tearDown", "classru_1_1sfedu_1_1grade_1_1_teacher_test_1_1_after_click_btns_test.html#a2797b44aadd7bb569c05b3b8b0608905", null ]
];