var dir_a2ada979a34dda9740cd42815f6e1b53 =
[
    [ "Helper.java", "_student_page_test_2_helper_8java.html", [
      [ "Helper", "classru_1_1sfedu_1_1grade_1_1_student_page_test_1_1_helper.html", "classru_1_1sfedu_1_1grade_1_1_student_page_test_1_1_helper" ]
    ] ],
    [ "PageOfDisciplin.java", "_page_of_disciplin_8java.html", [
      [ "PageOfDisciplin", "classru_1_1sfedu_1_1grade_1_1_student_page_test_1_1_page_of_disciplin.html", "classru_1_1sfedu_1_1grade_1_1_student_page_test_1_1_page_of_disciplin" ]
    ] ]
];