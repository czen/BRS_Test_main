var dir_235ca710f56af6003cd03de94157ead8 =
[
    [ "ForDekanatAccaunt.java", "_for_dekanat_accaunt_8java.html", [
      [ "ForDekanatAccaunt", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_dekanat_accaunt.html", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_dekanat_accaunt" ]
    ] ],
    [ "ForStudentAccaunt.java", "_for_student_accaunt_8java.html", [
      [ "ForStudentAccaunt", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_student_accaunt.html", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_student_accaunt" ]
    ] ],
    [ "ForTeacherAccaunt.java", "_for_teacher_accaunt_8java.html", [
      [ "ForTeacherAccaunt", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_teacher_accaunt.html", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_teacher_accaunt" ]
    ] ],
    [ "Helpers.java", "_helpers_8java.html", [
      [ "Helpers", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_helpers.html", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_helpers" ]
    ] ],
    [ "SimpleTests.java", "_simple_tests_8java.html", [
      [ "SimpleTests", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_simple_tests.html", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_simple_tests" ]
    ] ]
];