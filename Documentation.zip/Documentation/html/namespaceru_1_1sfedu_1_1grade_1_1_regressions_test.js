var namespaceru_1_1sfedu_1_1grade_1_1_regressions_test =
[
    [ "ForDekanatAccaunt", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_dekanat_accaunt.html", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_dekanat_accaunt" ],
    [ "ForStudentAccaunt", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_student_accaunt.html", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_student_accaunt" ],
    [ "ForTeacherAccaunt", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_teacher_accaunt.html", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_teacher_accaunt" ],
    [ "Helpers", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_helpers.html", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_helpers" ],
    [ "SimpleTests", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_simple_tests.html", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_simple_tests" ]
];