var classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_student_accaunt =
[
    [ "do_to_exam_journal", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_student_accaunt.html#a68e244bec2cb8c3714a9716027e7fbff", null ],
    [ "do_to_exam_marks", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_student_accaunt.html#ae8411e8b8249d08e313588e65e98d161", null ],
    [ "do_to_home", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_student_accaunt.html#a525493ca920842e6c920ad5c30155377", null ],
    [ "do_to_zach_jurnal", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_student_accaunt.html#ac0b49de62854bf0e1cb8329e6894c8cc", null ],
    [ "do_to_zach_marks", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_student_accaunt.html#a265f95d8074d1a71fcc50ef6337b0849", null ],
    [ "getDriver", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_student_accaunt.html#a8255e39470aef1aa0ef721e8399074f3", null ],
    [ "tearDown", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_student_accaunt.html#ad02f06298f896c33bd14cc3779940a89", null ],
    [ "url1", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_student_accaunt.html#aaf4862d91f22c4334dc08675273cc402", null ],
    [ "url2", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_student_accaunt.html#a8e88342ed495de7417d6e52ab4888ec0", null ],
    [ "url3", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_student_accaunt.html#aea5087e550632fc880cdd86f93f26bd5", null ],
    [ "url4", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_student_accaunt.html#ab5306237510d0d754ee63430485958a6", null ],
    [ "url5", "classru_1_1sfedu_1_1grade_1_1_regressions_test_1_1_for_student_accaunt.html#aa740ea76959ea65d67244a81f597a330", null ]
];